<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;

function contabo_dashboard_config() {
    return [
        'name' => 'Contabo VPS Dashboard',
        'description' => 'A global dashboard to manage and monitor all active Contabo VPS instances across your WHMCS system. Support: +977-9845870006.',
        'version' => '1.0',
        'author' => '<a href="https://cloudwebnepal.com" target="_blank">Cloud Web Nepal</a>',
        'fields' => [
            'license_key' => [
                'FriendlyName' => 'License Key',
                'Type'         => 'text',
                'Size'         => '50',
                'Description'  => 'Enter your license key obtained from Cloud Web Nepal. Support: +977-9845870006.',
                'Default'      => '',
            ]
        ]
    ];
}

function contabo_dashboard_output($vars) {
    $apiClassPath = ROOTDIR . '/modules/servers/contabo/lib/ContaboAPI.php';
    if (file_exists($apiClassPath)) {
        require_once $apiClassPath;
    } else {
        $fallbackPath = __DIR__ . '/../contabo/lib/ContaboAPI.php';
        if (file_exists($fallbackPath)) {
            require_once $fallbackPath;
        } else {
            echo '<div class="alert alert-danger"><strong>Error:</strong> Could not locate ContaboAPI.php.</div>';
            return;
        }
    }

    // ── 1. License Schema & Helper ───────────────────────────────────────────
    if (!Capsule::schema()->hasTable('mod_contabo_license')) {
        Capsule::schema()->create('mod_contabo_license', function ($table) {
            $table->string('setting')->unique();
            $table->text('value')->nullable();
        });
    }

    if (!function_exists('contabo_get_license_cache')) {
        function contabo_get_license_cache($setting) {
            try {
                return Capsule::table('mod_contabo_license')->where('setting', $setting)->value('value') ?: '';
            } catch (\Exception $e) { return ''; }
        }
    }
    
    function contabo_set_license_cache($setting, $value) {
        if (Capsule::table('mod_contabo_license')->where('setting', $setting)->count() > 0) {
            Capsule::table('mod_contabo_license')->where('setting', $setting)->update(['value' => $value]);
        } else {
            Capsule::table('mod_contabo_license')->insert(['setting' => $setting, 'value' => $value]);
        }
    }

    // ── 2. License Verification Logic ─────────────────────────────────────────
    $licenseKey = isset($vars['license_key']) ? trim($vars['license_key']) : '';
    $lastCheck  = (int)contabo_get_license_cache('last_check');
    $timeNow    = time();

    // Force verify if requested or if cache is older than 12 hours
    if (isset($_POST['contabo_action']) && $_POST['contabo_action'] === 'force_verify_license') {
        $lastCheck = 0; // Force
    }

    if ($licenseKey && ($timeNow - $lastCheck) > (12 * 3600)) {
        $ch = curl_init('https://cloudwebnepal.com/api2/index.php');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(['licensekey' => $licenseKey]));
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        $res = curl_exec($ch);
        curl_close($ch);
        
        $status = 'invalid';
        $expiry = '';
        $msg    = 'Unable to connect to license server.';

        if ($res) {
            $json = json_decode($res, true);
            if (is_array($json)) {
                $status = isset($json['status']) ? $json['status'] : 'invalid';
                $expiry = isset($json['expires']) ? $json['expires'] : '';
                $msg    = isset($json['message']) ? $json['message'] : '';
            }
        }
        
        contabo_set_license_cache('status', $status);
        contabo_set_license_cache('expiry', $expiry);
        contabo_set_license_cache('message', $msg);
        contabo_set_license_cache('last_check', $timeNow);
        
        if (isset($_POST['contabo_action']) && $_POST['contabo_action'] === 'force_verify_license') {
            echo '<div class="alert alert-info"><i class="fas fa-info-circle"></i> License re-verified: ' . htmlspecialchars($msg) . '</div>';
        }
    }

    $licenseStatus = contabo_get_license_cache('status');
    $licenseExpiry = contabo_get_license_cache('expiry');
    $licenseMsg    = contabo_get_license_cache('message');

    $servers = Capsule::table('tblservers')->where('type', 'contabo')->where('disabled', 0)->get();
    if (count($servers) === 0) {
        echo '<div class="alert alert-warning">No active Contabo servers found in WHMCS (Setup &rarr; Servers).</div>';
        return;
    }

    // If license is invalid, halt rendering the rest of the dashboard
    $isLicenseValid = ($licenseStatus === 'active' || $licenseStatus === 'valid');

    // ── Process Actions ──────────────────────────────────────────────────────
    if (isset($_POST['contabo_action'], $_POST['instance_id'], $_POST['server_id'])) {
        try {
            $action = $_POST['contabo_action'];
            $targetServer = Capsule::table('tblservers')->where('id', $_POST['server_id'])->first();
            if ($targetServer) {
                $apiUser     = trim($targetServer->username);
                $apiPassword = !empty($targetServer->password) ? trim(html_entity_decode(decrypt($targetServer->password), ENT_QUOTES)) : '';
                $lines       = explode("\n", str_replace("\r", "", trim($targetServer->accesshash)));
                $api         = new \Contabo\ContaboAPI(trim($lines[0]), trim($lines[1]), $apiUser, $apiPassword);

                if ($action === 'start')   $api->startInstance($_POST['instance_id']);
                elseif ($action === 'stop')    $api->stopInstance($_POST['instance_id']);
                elseif ($action === 'restart') $api->restartInstance($_POST['instance_id']);
                elseif ($action === 'assign') {
                    $clientId  = (int)$_POST['client_id'];
                    $productId = (int)$_POST['product_id'];
                    if ($clientId > 0 && $productId > 0) {
                        $client = Capsule::table('tblclients')->where('id', $clientId)->first();
                        if (!$client) throw new \Exception("Client ID {$clientId} not found.");
                        $serviceId = Capsule::table('tblhosting')->insertGetId([
                            'userid'       => $clientId,
                            'packageid'    => $productId,
                            'server'       => (int)$_POST['server_id'],
                            'domain'       => $_POST['server_name'],
                            'dedicatedip'  => $_POST['ip_address'],
                            'domainstatus' => 'Active',
                            'paymentmethod'=> 'paypal',
                            'billingcycle' => 'Monthly',
                            'regdate'      => date('Y-m-d'),
                            'nextduedate'  => date('Y-m-d', strtotime('+1 month')),
                            'notes'        => 'Instance ID: ' . $_POST['instance_id']
                        ]);
                        $cf = Capsule::table('tblcustomfields')->where('type','product')->where('relid',$productId)->where('fieldname','like','%Instance ID%')->first();
                        if ($cf) {
                            Capsule::table('tblcustomfieldsvalues')->insert(['fieldid'=>$cf->id,'relid'=>$serviceId,'value'=>$_POST['instance_id']]);
                        }
                        echo '<div class="alert alert-success" style="animation:fadeIn .5s"><i class="fas fa-check-circle"></i> Successfully assigned instance ' . htmlspecialchars($_POST['instance_id']) . ' to Client ID ' . $clientId . '!</div>';
                    } else {
                        throw new \Exception("Invalid Client ID or Product ID.");
                    }
                }

                if ($action !== 'assign') {
                    echo '<div class="alert alert-success" style="animation:fadeIn .5s"><i class="fas fa-check-circle"></i> Command sent to Instance: ' . htmlspecialchars($_POST['instance_id']) . '</div>';
                }
            }
        } catch (\Exception $e) {
            echo '<div class="alert alert-danger" style="animation:fadeIn .5s"><i class="fas fa-exclamation-circle"></i> Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
        }
    }

    // ── Fetch API Instances ───────────────────────────────────────────────────
    $apiErrors      = [];
    $allApiInstances = [];

    foreach ($servers as $server) {
        try {
            $apiUser     = trim($server->username);
            $apiPassword = !empty($server->password) ? trim(html_entity_decode(decrypt($server->password), ENT_QUOTES)) : '';
            $lines       = explode("\n", str_replace("\r", "", trim($server->accesshash)));
            $clientId    = isset($lines[0]) ? trim($lines[0]) : '';
            $clientSecret= isset($lines[1]) ? trim($lines[1]) : '';

            if ($clientId && $clientSecret) {
                $api  = new \Contabo\ContaboAPI($clientId, $clientSecret, $apiUser, $apiPassword);
                $resp = $api->getInstances();
                if (isset($resp['data'])) {
                    foreach ($resp['data'] as $inst) {
                        $list = isset($inst['instances']) ? $inst['instances'] : [$inst];
                        foreach ($list as $sub) {
                            $sub['whmcs_server_id'] = $server->id;
                            $allApiInstances[$sub['instanceId']] = $sub;
                        }
                    }
                } else if (isset($_POST['contabo_action']) && $_POST['contabo_action'] === 'fetch') {
                    $apiErrors[] = "Server {$server->name}: No instances found.";
                }
            } else if (isset($_POST['contabo_action']) && $_POST['contabo_action'] === 'fetch') {
                $apiErrors[] = "Server {$server->name}: Missing Client ID or Secret.";
            }
        } catch (\Exception $e) {
            if (isset($_POST['contabo_action']) && $_POST['contabo_action'] === 'fetch') {
                $apiErrors[] = "Server {$server->name}: " . $e->getMessage();
            }
        }
    }

    // ── Map WHMCS services ────────────────────────────────────────────────────
    $whmcsMap = [];
    $services = Capsule::table('tblhosting')
        ->join('tblclients', 'tblhosting.userid', '=', 'tblclients.id')
        ->whereIn('tblhosting.domainstatus', ['Active','Suspended','Pending'])
        ->select('tblhosting.id','tblhosting.userid','tblhosting.notes','tblclients.firstname','tblclients.lastname','tblclients.companyname')
        ->get();

    foreach ($services as $srv) {
        $instanceId = false;
        $cf = Capsule::table('tblcustomfieldsvalues')
            ->join('tblcustomfields','tblcustomfieldsvalues.fieldid','=','tblcustomfields.id')
            ->where('tblcustomfields.fieldname','like','%Instance ID%')
            ->where('tblcustomfieldsvalues.relid',$srv->id)
            ->first();
        if ($cf && !empty($cf->value)) $instanceId = trim($cf->value);
        elseif (preg_match('/Instance ID:\s*([0-9]+)/i', $srv->notes, $m)) $instanceId = $m[1];
        if ($instanceId) $whmcsMap[$instanceId] = $srv;
    }

    // ── Products dropdown ─────────────────────────────────────────────────────
    $contaboProducts = Capsule::table('tblproducts')
        ->join('tblproductgroups','tblproducts.gid','=','tblproductgroups.id')
        ->where('tblproducts.servertype','contabo')
        ->select('tblproducts.id','tblproducts.name','tblproductgroups.name as groupname','tblproducts.servertype')
        ->get();

    // If no Contabo-specific products exist, fall back to ALL products
    if (count($contaboProducts) === 0) {
        $contaboProducts = Capsule::table('tblproducts')
            ->join('tblproductgroups','tblproducts.gid','=','tblproductgroups.id')
            ->select('tblproducts.id','tblproducts.name','tblproductgroups.name as groupname','tblproducts.servertype')
            ->orderBy('tblproductgroups.name')
            ->orderBy('tblproducts.name')
            ->get();
    }

    $productOptions = '';
    foreach ($contaboProducts as $p) {
        $moduleTag = $p->servertype ? ' [' . $p->servertype . ']' : '';
        $productOptions .= '<option value="' . $p->id . '">' . htmlspecialchars($p->groupname . ' - ' . $p->name . $moduleTag) . '</option>';
    }

    // ── Clients dropdown ──────────────────────────────────────────────────────
    $allClients = Capsule::table('tblclients')->orderBy('firstname')->select('id','firstname','lastname','companyname')->get();
    $clientOptions = '';
    foreach ($allClients as $c) {
        $lbl = htmlspecialchars($c->firstname . ' ' . $c->lastname);
        if (!empty($c->companyname)) $lbl .= ' (' . htmlspecialchars($c->companyname) . ')';
        $lbl .= ' — #' . $c->id;
        $clientOptions .= '<option value="' . $c->id . '">' . $lbl . '</option>';
    }

    // ── Global Activity Logs ──────────────────────────────────────────────────
    $globalLogs = Capsule::table('tblactivitylog')
        ->where('description', 'like', '%Contabo VPS:%')
        ->orderBy('id', 'desc')
        ->limit(100)
        ->get();

    // ── Render ────────────────────────────────────────────────────────────────
    ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
    .contabo-dashboard { font-family: "Inter", sans-serif; }
    .contabo-dashboard .header-card { background: linear-gradient(135deg, #0d6efd, #0043a8); color: white; padding: 25px 30px; border-radius: 10px; margin-bottom: 25px; box-shadow: 0 4px 15px rgba(13,110,253,0.2); }
    .contabo-dashboard .header-card h2 { margin: 0; font-weight: 700; color: #fff; font-size: 24px; }
    .contabo-dashboard .header-card p  { margin: 5px 0 0 0; opacity: 0.9; }
    .contabo-dashboard .table-container { background: #fff; padding: 25px; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.04); border: 1px solid #edf2f9; }
    .pulse-badge { display: inline-flex; align-items: center; gap: 5px; padding: 5px 12px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
    .status-running { background: #d1e7dd; color: #0f5132; animation: pulse-glow 2s infinite; }
    .status-stopped { background: #fff3cd; color: #856404; }
    .status-unknown { background: #e2e3e5; color: #383d41; }
    @keyframes pulse-glow { 0%,100%{ box-shadow:0 0 0 0 rgba(25,135,84,.5); } 50%{ box-shadow:0 0 0 5px rgba(25,135,84,0); } }
    @keyframes fadeIn { from{opacity:0;transform:translateY(-8px)} to{opacity:1;transform:translateY(0)} }
    @keyframes spin   { to{ transform:rotate(360deg) } }
    .btn-power { border:none; border-radius:8px; width:34px; height:34px; display:inline-flex; align-items:center; justify-content:center; font-size:13px; cursor:pointer; transition:all .2s; position:relative; overflow:hidden; }
    .btn-power:hover   { transform:translateY(-2px); box-shadow:0 4px 12px rgba(0,0,0,.25); }
    .btn-power:active  { transform:scale(.93); }
    .btn-power.loading { pointer-events:none; opacity:.75; }
    .btn-power .btn-icon{ transition:opacity .2s; }
    .btn-power .btn-spin{ display:none; width:13px; height:13px; border:2px solid rgba(255,255,255,.35); border-top-color:#fff; border-radius:50%; animation:spin .7s linear infinite; position:absolute; }
    .btn-power.loading .btn-icon{ opacity:0; }
    .btn-power.loading .btn-spin{ display:block; }
    .btn-start   { background:linear-gradient(135deg,#28a745,#1a7a30); color:#fff; }
    .btn-stop    { background:linear-gradient(135deg,#fd7e14,#d96800); color:#fff; }
    .btn-restart { background:linear-gradient(135deg,#dc3545,#a71d2a); color:#fff; }
    .power-cell  { display:flex; gap:6px; justify-content:center; align-items:center; }
    .select2-container { width:100% !important; }
    .select2-container--default .select2-selection--single { height:40px; border:1px solid #ced4da; border-radius:8px; }
    .select2-container--default .select2-selection--single .select2-selection__rendered { line-height:38px; padding:0 12px; font-size:13px; }
    .select2-container--default .select2-selection--single .select2-selection__arrow { height:38px; }

    /* Custom Tabs */
    .c-nav-tabs { display: flex; flex-wrap: wrap; padding-left: 0; margin-bottom: 20px; list-style: none; border-bottom: 2px solid #e9ecef; }
    .c-nav-tabs .c-nav-item { margin-bottom: -2px; }
    .c-nav-tabs .c-nav-link { background: transparent; border: 2px solid transparent; border-top-left-radius: 8px; border-top-right-radius: 8px; padding: 12px 20px; font-weight: 700; cursor: pointer; transition: all 0.2s; color: #6c757d; }
    .c-nav-tabs .c-nav-link:hover { color: #0d6efd; background: #f8f9fa; }
    .c-nav-tabs .c-nav-link.active { color: #0d6efd; border-color: #e9ecef #e9ecef #fff; border-bottom-color: #0d6efd; background: #fff; }
    .c-tab-content > .c-tab-pane { display: none; }
    .c-tab-content > .c-tab-pane.active { display: block; animation: fadeIn 0.4s; }
    </style>

    <div class="contabo-dashboard">

      <!-- Header -->
      <div class="header-card">
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div>
            <h2><i class="fas fa-server"></i> Advanced Contabo Dashboard</h2>
            <p>Live sync of all API instances. Power controls can be triggered directly.</p>
            <form method="post" style="margin-top:15px;">
              <input type="hidden" name="contabo_action" value="fetch">
              <button type="submit" class="btn btn-light btn-sm fw-bold" style="color:#0043a8;">
                <i class="fas fa-sync-alt"></i> Fetch Servers (Sync API)
              </button>
            </form>
          </div>
          <div style="text-align:right;">
            <span style="display:block;font-weight:600;">Developed by <a href="https://cloudwebnepal.com" target="_blank" style="color:#fff;text-decoration:underline;">Cloud Web Nepal</a></span>
            <span style="font-size:13px;opacity:.8;"><i class="fas fa-headset"></i> Support: +977-9845870006</span>
          </div>
        </div>
      </div>

      <?php if (!empty($apiErrors)): ?>
        <div class="alert alert-danger" style="animation:fadeIn .5s; border-left:5px solid #dc3545; box-shadow:0 4px 10px rgba(220,53,69,.1);">
          <h5 style="margin-top:0;font-weight:600;color:#b02a37;"><i class="fas fa-exclamation-triangle"></i> API Fetch Errors</h5>
          <ul style="margin-bottom:10px;"><?php foreach ($apiErrors as $err): ?><li><?= htmlspecialchars($err) ?></li><?php endforeach; ?></ul>
          <hr style="border-top-color:#f5c2c7;">
          <p style="margin-bottom:0;font-size:13px;"><strong>How to fix:</strong> Go to <strong>Setup &rarr; Servers</strong>, click your Contabo Server, and verify Username, Password, and Access Hash.</p>
        </div>
      <?php elseif (isset($_POST['contabo_action']) && $_POST['contabo_action'] === 'fetch'): ?>
        <div class="alert alert-success" style="animation:fadeIn .5s;"><i class="fas fa-check-circle"></i> Successfully synced API data from Contabo!</div>
      <?php endif; ?>

      <!-- Nav Tabs -->
      <ul class="c-nav-tabs">
        <?php if ($isLicenseValid): ?>
        <li class="c-nav-item">
          <button class="c-nav-link active" data-target="#instances"><i class="fas fa-server me-2"></i> Instances Overview</button>
        </li>
        <li class="c-nav-item">
          <button class="c-nav-link" data-target="#activity"><i class="fas fa-history me-2"></i> Global Activity Logs</button>
        </li>
        <?php endif; ?>
        <li class="c-nav-item">
          <button class="c-nav-link <?= !$isLicenseValid ? 'active' : '' ?>" data-target="#license"><i class="fas fa-key me-2"></i> License Details</button>
        </li>
      </ul>

      <div class="c-tab-content">
        <?php if ($isLicenseValid): ?>
        <!-- Instances Tab -->
        <div class="c-tab-pane active" id="instances">
          <div class="table-container">
            <table id="contaboInstancesTable" class="table table-hover table-striped" style="width:100%;vertical-align:middle;">
              <thead style="background:#f8f9fa;">
            <tr>
              <th style="font-weight:600;color:#495057;">Server Name (OS)</th>
              <th style="font-weight:600;color:#495057;">IP Address</th>
              <th style="font-weight:600;color:#495057;">Status</th>
              <th style="font-weight:600;color:#495057;">Assigned To (WHMCS)</th>
              <th style="font-weight:600;color:#495057;text-align:center;">Power Controls</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach ($allApiInstances as $instanceId => $apiData):
            $serverName = !empty($apiData['displayName']) ? $apiData['displayName'] : ($apiData['name'] ?? '');
            $os         = $apiData['osType'] ?? 'Linux';
            $ipAddress  = $apiData['ipConfig']['v4']['ip'] ?? 'N/A';
            $apiStatus  = strtolower($apiData['status'] ?? '');

            if ($apiStatus === 'ok') {
                $statusHtml = '<span class="pulse-badge status-running"><i class="fas fa-circle" style="font-size:8px;"></i> RUNNING</span>';
            } else {
                $statusHtml = '<span class="pulse-badge status-stopped"><i class="fas fa-stop-circle"></i> ' . strtoupper($apiStatus) . '</span>';
            }

            if (isset($whmcsMap[$instanceId])) {
                $srv        = $whmcsMap[$instanceId];
                $clientName = $srv->firstname . ' ' . $srv->lastname;
                if (!empty($srv->companyname)) $clientName .= ' (' . $srv->companyname . ')';
                $assignedHtml = '<a href="clientssummary.php?userid=' . $srv->userid . '" style="font-weight:600;color:#0d6efd;">' . htmlspecialchars($clientName) . '</a><br>'
                    . '<a href="clientsservices.php?userid=' . $srv->userid . '&id=' . $srv->id . '" style="font-size:11px;color:#6c757d;"><i class="fas fa-external-link-alt"></i> View Service</a>';
            } else {
                $assignedHtml = '<span class="badge bg-secondary" style="margin-bottom:5px;">Unassigned (API Only)</span><br>'
                    . '<button type="button" class="btn btn-sm btn-outline-primary" style="font-size:10px;padding:2px 6px;" '
                    . 'onclick="openAssignModal(\'' . $instanceId . '\',\'' . htmlspecialchars($serverName, ENT_QUOTES) . '\',\'' . htmlspecialchars($ipAddress, ENT_QUOTES) . '\',\'' . $apiData['whmcs_server_id'] . '\')">'
                    . '<i class="fas fa-link"></i> Assign to Client</button>';
            }
          ?>
            <tr>
              <td><strong style="color:#495057;"><?= htmlspecialchars($serverName) ?></strong><br><small class="text-muted"><i class="fab fa-linux"></i> <?= htmlspecialchars($os) ?></small></td>
              <td><strong class="text-primary"><?= htmlspecialchars($ipAddress) ?></strong></td>
              <td><?= $statusHtml ?></td>
              <td><?= $assignedHtml ?></td>
              <td>
                <div class="power-cell">
                  <button type="button" class="btn-power btn-start"   title="Start"   onclick="doAction(this,'start','<?= $instanceId ?>','<?= $apiData['whmcs_server_id'] ?>')"><span class="btn-icon"><i class="fas fa-play"></i></span><span class="btn-spin"></span></button>
                  <button type="button" class="btn-power btn-stop"    title="Stop"    onclick="doAction(this,'stop','<?= $instanceId ?>','<?= $apiData['whmcs_server_id'] ?>')"><span class="btn-icon"><i class="fas fa-stop"></i></span><span class="btn-spin"></span></button>
                  <button type="button" class="btn-power btn-restart" title="Restart" onclick="doAction(this,'restart','<?= $instanceId ?>','<?= $apiData['whmcs_server_id'] ?>')"><span class="btn-icon"><i class="fas fa-sync-alt"></i></span><span class="btn-spin"></span></button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div> <!-- End Instances Tab -->

      <!-- Activity Tab -->
      <div class="c-tab-pane" id="activity">
        <div class="table-container">
          <table id="contaboActivityTable" class="table table-hover table-striped" style="width:100%;vertical-align:middle;">
            <thead style="background:#f8f9fa;">
              <tr>
                <th style="font-weight:600;color:#495057;width:150px;">Date</th>
                <th style="font-weight:600;color:#495057;">User / IP</th>
                <th style="font-weight:600;color:#495057;">Description</th>
              </tr>
            </thead>
            <tbody>
            <?php foreach ($globalLogs as $log): ?>
              <tr>
                <td style="font-size:13px;color:#6c757d;white-space:nowrap;"><i class="far fa-clock"></i> <?= $log->date ?></td>
                <td>
                  <?php if ($log->userid > 0): ?>
                    <a href="clientssummary.php?userid=<?= $log->userid ?>" style="font-weight:600;"><i class="fas fa-user"></i> Client #<?= $log->userid ?></a>
                  <?php else: ?>
                    <span class="badge bg-secondary">System / Admin</span>
                  <?php endif; ?>
                  <br><small class="text-muted"><?= htmlspecialchars($log->ipaddr) ?></small>
                </td>
                <td style="font-weight:500;color:#343a40;"><?= htmlspecialchars($log->description) ?></td>
              </tr>
            <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div> <!-- End Activity Tab -->
      <?php endif; ?>

      <!-- License Details Tab -->
      <div class="c-tab-pane <?= !$isLicenseValid ? 'active' : '' ?>" id="license">
        <div class="table-container text-center" style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
          <?php if ($isLicenseValid): ?>
              <i class="fas fa-check-circle text-success" style="font-size: 60px; margin-bottom: 20px;"></i>
              <h3 style="font-weight: 700; color: #198754;">License is Active</h3>
          <?php else: ?>
              <i class="fas fa-times-circle text-danger" style="font-size: 60px; margin-bottom: 20px;"></i>
              <h3 style="font-weight: 700; color: #dc3545;">License Invalid or Expired</h3>
              <p class="text-muted">You must enter a valid license key in the Addon Module configuration to use this module.</p>
          <?php endif; ?>
          
          <div style="background: #f8f9fa; border-radius: 10px; padding: 25px; text-align: left; margin-top: 30px; border: 1px solid #e9ecef;">
            <p style="margin-bottom: 10px;"><strong>Status:</strong> <span class="badge bg-<?= $licenseStatus === 'active' ? 'success' : 'danger' ?>"><?= strtoupper($licenseStatus ?: 'UNLICENSED') ?></span></p>
            <p style="margin-bottom: 10px;"><strong>Expiry Date:</strong> <?= htmlspecialchars($licenseExpiry ?: 'N/A') ?></p>
            <p style="margin-bottom: 10px;"><strong>License Key:</strong> <?= htmlspecialchars($licenseKey ? substr($licenseKey, 0, 5) . '****' . substr($licenseKey, -4) : 'Not configured') ?></p>
            <p style="margin-bottom: 0;"><strong>Last Message:</strong> <?= htmlspecialchars($licenseMsg ?: 'N/A') ?></p>
          </div>
          
          <form method="post" style="margin-top: 25px;">
            <input type="hidden" name="contabo_action" value="force_verify_license">
            <button type="submit" class="btn btn-primary fw-bold px-4 py-2"><i class="fas fa-sync-alt me-2"></i> Force Verify License</button>
          </form>
        </div>
      </div> <!-- End License Details Tab -->
      
    </div> <!-- End Tab Content -->

    <?php if ($isLicenseValid): ?>
    <!-- Hidden power action form -->
    <form method="post" id="powerActionForm" style="display:none;">
      <input type="hidden" name="contabo_action" id="pa_action">
      <input type="hidden" name="server_id"      id="pa_server">
      <input type="hidden" name="instance_id"    id="pa_instance">
    </form>

    <!-- Confirm Modal -->
    <div class="modal fade" id="confirmModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-sm" style="margin-top:130px;">
        <div class="modal-content" style="border-radius:14px;border:none;box-shadow:0 20px 60px rgba(0,0,0,.2);">
          <div class="modal-body text-center" style="padding:32px 24px;">
            <div id="c-icon" style="font-size:44px;margin-bottom:12px;"></div>
            <h5 id="c-title" style="font-weight:700;margin-bottom:6px;"></h5>
            <p id="c-msg" style="color:#6c757d;font-size:13px;margin-bottom:22px;"></p>
            <div style="display:flex;gap:10px;justify-content:center;">
              <button class="btn btn-light" data-bs-dismiss="modal" style="border-radius:8px;min-width:80px;">Cancel</button>
              <button id="confirmBtn" class="btn fw-bold" style="border-radius:8px;min-width:110px;">Confirm</button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Assign Modal -->
    <div class="modal fade" id="assignModal" tabindex="-1" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content" style="border-radius:14px;border:none;box-shadow:0 20px 60px rgba(0,0,0,.2);">
          <form method="post" id="assignForm">
            <input type="hidden" name="contabo_action" value="assign">
            <input type="hidden" name="instance_id" id="a-inst">
            <input type="hidden" name="server_name"  id="a-name">
            <input type="hidden" name="ip_address"   id="a-ip">
            <input type="hidden" name="server_id"    id="a-sid">
            <input type="hidden" name="client_id"    id="a-cid">
            <div class="modal-header" style="background:linear-gradient(135deg,#0d6efd,#0043a8);border-radius:14px 14px 0 0;padding:20px 25px;">
              <h5 class="modal-title" style="font-weight:700;color:#fff;font-size:17px;"><i class="fas fa-link"></i> Assign Server to Client</h5>
              <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" style="padding:25px;">
              <div class="alert mb-3" style="background:#eef4ff;border-left:4px solid #0d6efd;border-radius:8px;font-size:13px;padding:12px 16px;">
                <i class="fas fa-info-circle text-primary"></i> Assigning <strong id="a-disp"></strong> to a WHMCS client.
              </div>
              <div class="mb-3">
                <label style="font-weight:700;font-size:13px;color:#495057;display:block;margin-bottom:5px;"><i class="fas fa-user"></i> Select Client</label>
                <select id="clientDropdown" style="width:100%;" required>
                  <option value="">-- Search or select a client --</option>
                  <?= $clientOptions ?>
                </select>
                <small class="text-muted">Type name, company, or client ID to search.</small>
              </div>
              <div class="mb-1">
                <label style="font-weight:700;font-size:13px;color:#495057;display:block;margin-bottom:5px;"><i class="fas fa-box"></i> Product / Service</label>
                <select name="product_id" class="form-select" style="border-radius:8px;" required>
                  <option value="">-- Select a Contabo Product --</option>
                  <?= $productOptions ?>
                </select>
              </div>
            </div>
            <div class="modal-footer" style="background:#f8f9fa;border-top:1px solid #edf2f9;border-radius:0 0 14px 14px;padding:15px 25px;">
              <button type="button" class="btn btn-light" data-bs-dismiss="modal" style="border-radius:8px;">Cancel</button>
              <button type="submit" class="btn btn-primary fw-bold" style="border-radius:8px;padding:8px 22px;"><i class="fas fa-save"></i> Save Assignment</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
    var actionMeta = {
      start:   { icon:'&#9654;', color:'#28a745', title:'Start Server',   msg:'This will power on the server.' },
      stop:    { icon:'&#9632;', color:'#fd7e14', title:'Stop Server',    msg:'This will power off the server.' },
      restart: { icon:'&#8635;', color:'#dc3545', title:'Restart Server', msg:'This will reboot the server. Expect brief downtime.' }
    };
    var pendingBtn = null;

    function doAction(btn, action, instanceId, serverId) {
      var m = actionMeta[action];
      jQuery('#c-icon').html(m.icon).css('color', m.color);
      jQuery('#c-title').text(m.title);
      jQuery('#c-msg').text(m.msg);
      jQuery('#confirmBtn').css({ background: m.color, borderColor: m.color, color: '#fff' }).text('Yes, ' + action);
      jQuery('#pa_action').val(action);
      jQuery('#pa_instance').val(instanceId);
      jQuery('#pa_server').val(serverId);
      pendingBtn = btn;
      jQuery('#confirmModal').modal('show');
    }

    jQuery('#confirmBtn').on('click', function () {
      jQuery('#confirmModal').modal('hide');
      if (pendingBtn) jQuery(pendingBtn).addClass('loading');
      jQuery('#powerActionForm').submit();
    });

    function openAssignModal(instanceId, serverName, ipAddress, serverId) {
      jQuery('#a-inst').val(instanceId);
      jQuery('#a-name').val(serverName);
      jQuery('#a-ip').val(ipAddress);
      jQuery('#a-sid').val(serverId);
      jQuery('#a-disp').text(serverName + ' (' + ipAddress + ')');
      jQuery('#assignModal').modal('show');
    }

    jQuery('#assignForm').on('submit', function () {
      jQuery('#a-cid').val(jQuery('#clientDropdown').val());
    });

    jQuery(document).ready(function () {
      jQuery('#clientDropdown').select2({
        dropdownParent: jQuery('#assignModal'),
        placeholder: 'Search by name, company, or ID...',
        allowClear: true,
        width: '100%'
      });

      jQuery('#contaboInstancesTable').DataTable({
        pageLength: 25,
        language: { search: 'Search Instances:' }
      });

      jQuery('#contaboActivityTable').DataTable({
        pageLength: 25,
        order: [[0, 'desc']],
        language: { search: 'Search Logs:' }
      });

      // Custom Tab Logic
      jQuery('.c-nav-link').on('click', function(e) {
          e.preventDefault();
          jQuery('.c-nav-link').removeClass('active');
          jQuery(this).addClass('active');
          
          jQuery('.c-tab-pane').removeClass('active');
          var target = jQuery(this).attr('data-target');
          jQuery(target).addClass('active');
      });
    });
    </script>
    <?php
}
