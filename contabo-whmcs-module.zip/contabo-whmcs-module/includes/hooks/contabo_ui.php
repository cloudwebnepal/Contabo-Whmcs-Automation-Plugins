<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

/**
 * Contabo UI Hook - Splits "Access Hash" into two dedicated input fields
 * for Contabo Client ID and Client Secret on the WHMCS Server Setup page.
 */
add_hook('AdminAreaHeadOutput', 1, function($vars) {
    if (strpos($_SERVER['REQUEST_URI'], 'configservers') === false) {
        return '';
    }
    if (!isset($_GET['action']) || $_GET['action'] !== 'manage') {
        return '';
    }

    return '<style>
    #contabo_custom_fields label { font-weight: 600; font-size: 13px; display: block; margin-bottom: 4px; color: #333; }
    #contabo_custom_fields input { border: 1px solid #ccc; border-radius: 4px; padding: 6px 10px; width: 100%; max-width: 420px; font-size: 13px; }
    #contabo_custom_fields input:focus { border-color: #0d6efd; outline: none; box-shadow: 0 0 0 2px rgba(13,110,253,0.15); }
    #contabo_custom_fields .field-hint { font-size: 11px; color: #888; margin-top: 3px; }
    </style>';
});

add_hook('AdminAreaFooterOutput', 1, function($vars) {
    if (strpos($_SERVER['REQUEST_URI'], 'configservers') === false) {
        return '';
    }
    if (!isset($_GET['action']) || $_GET['action'] !== 'manage') {
        return '';
    }

    return '<script>
(function waitForJQuery() {
    if (typeof jQuery === "undefined") {
        setTimeout(waitForJQuery, 100);
        return;
    }
    jQuery(function($) {

        function injectContaboFields() {
            // Find the textarea - try multiple selectors
            var $textarea = $("textarea[name=accesshash]");
            if (!$textarea.length) $textarea = $("textarea[name=\'accesshash\']");
            if (!$textarea.length) {
                // Try finding by row label
                $("td").each(function() {
                    if ($(this).text().trim() === "Access Hash") {
                        $textarea = $(this).next("td").find("textarea");
                    }
                });
            }

            var $moduleSelect = $("select[name=type]");
            if (!$moduleSelect.length) $moduleSelect = $("select[name=\'type\']");

            if (!$textarea.length || !$moduleSelect.length) return;

            function rebuild() {
                var isContabo = ($moduleSelect.val() === "contabo");

                if (isContabo) {
                    if ($("#contabo_custom_fields").length) {
                        $("#contabo_custom_fields").show();
                        $textarea.hide();
                        return;
                    }

                    var parts = $textarea.val().split("\n");
                    var existingId = parts[0] ? parts[0].trim() : "";
                    var existingSecret = parts[1] ? parts[1].trim() : "";

                    $textarea.hide();

                    var html = \'<div id="contabo_custom_fields" style="margin-top:8px;">\' +
                        \'<div style="margin-bottom:12px;">\' +
                          \'<label>Contabo Client ID</label>\' +
                          \'<input type="text" id="contabo_cid" value="\' + existingId + \'" placeholder="e.g. INT-14345990">\' +
                          \'<div class="field-hint">Found in your Contabo Control Panel &rarr; API section</div>\' +
                        \'</div>\' +
                        \'<div>\' +
                          \'<label>Contabo Client Secret</label>\' +
                          \'<input type="password" id="contabo_csecret" value="\' + existingSecret + \'">\' +
                          \'<div class="field-hint">The secret key paired with your Client ID</div>\' +
                        \'</div>\' +
                    \'</div>\';

                    $textarea.after(html);

                    // Real-time sync back to hidden textarea
                    function sync() {
                        $textarea.val($("#contabo_cid").val().trim() + "\n" + $("#contabo_csecret").val().trim());
                    }
                    $(document).on("keyup change", "#contabo_cid, #contabo_csecret", sync);
                    // Also sync on any button click (Test Connection uses AJAX)
                    $(document).on("click", "button, input[type=submit], input[type=button]", sync);

                } else {
                    $("#contabo_custom_fields").hide();
                    $textarea.show();
                }
            }

            rebuild();
            $moduleSelect.on("change", rebuild);
        }

        // Try immediately and also after a short delay (for slow WHMCS renders)
        injectContaboFields();
        setTimeout(injectContaboFields, 500);
        setTimeout(injectContaboFields, 1500);
    });
})();
</script>';
});
