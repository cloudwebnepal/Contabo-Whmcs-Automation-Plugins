<?php
namespace Contabo;

class ContaboAPI {
    private $clientId;
    private $clientSecret;
    private $apiUser;
    private $apiPassword;
    private $token = null;
    
    private $authUrl = 'https://auth.contabo.com/auth/realms/contabo/protocol/openid-connect/token';
    private $apiUrl = 'https://api.contabo.com';

    /**
     * Generate a valid UUID4 for the x-request-id header required by Contabo
     */
    private function generateUUID4() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }

    public function __construct($clientId, $clientSecret, $apiUser, $apiPassword) {
        $this->clientId = $clientId;
        $this->clientSecret = $clientSecret;
        $this->apiUser = $apiUser;
        $this->apiPassword = $apiPassword;
    }

    /**
     * Get OAuth2 Access Token
     */
    private function getAccessToken() {
        if ($this->token !== null) {
            return $this->token;
        }

        $postParams = [
            'client_id' => $this->clientId,
            'client_secret' => $this->clientSecret,
            'username' => $this->apiUser,
            'password' => $this->apiPassword,
            'grant_type' => 'password'
        ];

        $ch = curl_init($this->authUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postParams));
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode == 200) {
            $data = json_decode($response, true);
            if (isset($data['access_token'])) {
                $this->token = $data['access_token'];
                return $this->token;
            }
        }
        
        throw new \Exception("Contabo API Authentication Failed. Response: " . $response);
    }

    /**
     * Make an API Request
     */
    private function request($method, $endpoint, $data = null) {
        $token = $this->getAccessToken();
        
        $url = rtrim($this->apiUrl, '/') . '/' . ltrim($endpoint, '/');
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
        
        $headers = [
            'Authorization: Bearer ' . $token,
            'Accept: application/json',
            'x-request-id: ' . $this->generateUUID4()
        ];

        if ($data !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            $headers[] = 'Content-Type: application/json';
        }
        
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new \Exception("cURL Error: " . $error);
        }

        $decoded = json_decode($response, true);
        
        if ($httpCode >= 200 && $httpCode < 300) {
            return $decoded ?: true;
        } else {
            $errMsg = 'Unknown API Error';
            if (isset($decoded['message'])) {
                $errMsg = is_array($decoded['message']) ? implode(', ', $decoded['message']) : $decoded['message'];
            }
            throw new \Exception("Contabo API Error ($httpCode): " . $errMsg);
        }
    }

    // --------------------------------------------------------------------------------
    // Instances
    // --------------------------------------------------------------------------------

    public function createInstance($imageId, $region, $productId, $sshKeys = []) {
        $data = [
            'imageId' => $imageId,
            'region' => $region,
            'productId' => $productId,
        ];
        if (!empty($sshKeys)) {
            $data['sshKeys'] = $sshKeys;
        }
        return $this->request('POST', '/v1/compute/instances', $data);
    }

    public function getInstance($instanceId) {
        return $this->request('GET', "/v1/compute/instances/{$instanceId}");
    }

    public function getInstances() {
        return $this->request('GET', "/v1/compute/instances");
    }

    public function updateInstance($instanceId, $displayName) {
        $data = ['displayName' => $displayName];
        return $this->request('PATCH', "/v1/compute/instances/{$instanceId}", $data);
    }

    public function cancelInstance($instanceId) {
        // Note: Contabo API terminate is usually done via a cancel endpoint or instance deletion
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/cancel");
    }

    // --------------------------------------------------------------------------------
    // Actions
    // --------------------------------------------------------------------------------

    public function startInstance($instanceId) {
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/actions/start");
    }

    public function stopInstance($instanceId) {
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/actions/stop");
    }

    public function shutdownInstance($instanceId) {
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/actions/shutdown");
    }

    public function restartInstance($instanceId) {
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/actions/restart");
    }

    public function reinstallInstance($instanceId, $imageId) {
        $data = ['imageId' => $imageId];
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/actions/reinstall", $data);
    }

    public function resetPassword($instanceId, $rootPassword) {
        $data = ['rootPassword' => $rootPassword];
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/actions/resetPassword", $data);
    }

    // --------------------------------------------------------------------------------
    // Snapshots
    // --------------------------------------------------------------------------------

    public function getSnapshots($instanceId) {
        return $this->request('GET', "/v1/compute/instances/{$instanceId}/snapshots");
    }

    public function createSnapshot($instanceId, $name, $description = '') {
        $data = [
            'name' => $name
        ];
        if (!empty(trim($description))) {
            $data['description'] = $description;
        }
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/snapshots", $data);
    }

    public function rollbackSnapshot($instanceId, $snapshotId) {
        return $this->request('POST', "/v1/compute/instances/{$instanceId}/snapshots/{$snapshotId}/actions/rollback");
    }

    public function deleteSnapshot($instanceId, $snapshotId) {
        return $this->request('DELETE', "/v1/compute/instances/{$instanceId}/snapshots/{$snapshotId}");
    }

    // --------------------------------------------------------------------------------
    // Images
    // --------------------------------------------------------------------------------

    public function getImages() {
        return $this->request('GET', "/v1/compute/images");
    }
}
