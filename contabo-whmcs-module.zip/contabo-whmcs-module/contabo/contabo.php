<?php
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

require_once __DIR__ . '/lib/ContaboAPI.php';

use Contabo\ContaboAPI;
use WHMCS\Database\Capsule;

// License Cache Helper
if (!function_exists('contabo_get_license_cache')) {
    function contabo_get_license_cache($setting) {
        try {
            if (class_exists('\WHMCS\Database\Capsule') && Capsule::schema()->hasTable('mod_contabo_license')) {
                return Capsule::table('mod_contabo_license')->where('setting', $setting)->value('value') ?: '';
            }
        } catch (\Exception $e) {}
        return '';
    }
}

// Global License Verifier
function contabo_is_license_valid() {
    $status = contabo_get_license_cache('status');
    return ($status === 'active' || $status === 'valid');
}

function contabo_MetaData() {
    return [
        'DisplayName' => 'Contabo Cloud VPS',
        'APIVersion' => '1.1',
        'RequiresServer' => true,
        'DefaultNonSSLPort' => '80',
        'DefaultSSLPort' => '443',
        'ServiceSingleSignOnLabel' => 'Login to Panel',
    ];
}

function contabo_ConfigOptions() {
    return [
        'Region' => [
            'Type' => 'text',
            'Size' => '25',
            'Default' => 'EU',
            'Description' => 'e.g. EU, US-central, US-east, US-west, SIN',
        ],
        'Product ID' => [
            'Type' => 'text',
            'Size' => '25',
            'Default' => 'V6',
            'Description' => 'The Contabo Product ID (e.g., V6 for VPS S, V7 for VPS M)',
        ],
        'Default Image ID' => [
            'Type' => 'text',
            'Size' => '25',
            'Default' => 'f4d54694-8ab3-4cda-92c9-6e3e56a4cf88',
            'Description' => 'The default OS Image ID (e.g. Ubuntu 20.04)',
        ],
        'Hostname Prefix' => [
            'Type' => 'text',
            'Size' => '25',
            'Default' => 'vps-',
            'Description' => 'Prefix for auto-generated hostnames if not provided by client.',
        ],
    ];
}

/**
 * Helper to get the API Client instance
 */
function contabo_getApiClient($params) {
    $apiUser = trim($params['serverusername']);
    $apiPassword = trim(html_entity_decode($params['serverpassword'], ENT_QUOTES));
    
    // We expect Client ID and Secret to be stored in the Access Hash, one per line
    $accessHash = trim($params['serveraccesshash']);
    $lines = explode("\n", str_replace("\r", "", $accessHash));
    
    $clientId = isset($lines[0]) ? trim($lines[0]) : '';
    $clientSecret = isset($lines[1]) ? trim($lines[1]) : '';
    
    if (empty($clientId) || empty($clientSecret)) {
        throw new \Exception("Client ID and Client Secret must be configured in the Server Access Hash field (Line 1: Client ID, Line 2: Client Secret).");
    }

    return new ContaboAPI($clientId, $clientSecret, $apiUser, $apiPassword);
}

function contabo_TestConnection($params) {
    try {
        $apiUser = trim($params['serverusername']);
        $apiPassword = trim(html_entity_decode($params['serverpassword'], ENT_QUOTES));
        $accessHash = trim($params['serveraccesshash']);
        $lines = explode("\n", str_replace("\r", "", $accessHash));
        $clientId = isset($lines[0]) ? trim($lines[0]) : '';
        $clientSecret = isset($lines[1]) ? trim($lines[1]) : '';

        if (empty($clientId) || empty($clientSecret)) {
            return ['success' => false, 'error' => 'Missing credentials. Put Client ID on line 1 and Client Secret on line 2 of the Access Hash field.'];
        }
        if (empty($apiUser)) {
            return ['success' => false, 'error' => 'Username is empty. Enter your Contabo account email address.'];
        }
        if (empty($apiPassword)) {
            return ['success' => false, 'error' => 'Password is empty. Enter your Contabo API Password (generated in Contabo Panel → API section, NOT your regular login password).'];
        }

        $api = new ContaboAPI($clientId, $clientSecret, $apiUser, $apiPassword);
        $response = $api->getInstances();
        
        if (isset($response['data'])) {
            return ['success' => true, 'error' => ''];
        }
        
        return ['success' => false, 'error' => 'Connected but received unexpected response. Credentials may be valid — try saving and using the dashboard.'];
    } catch (\Exception $e) {
        $msg = $e->getMessage();
        // Add helpful hint if it's a credentials issue
        if (strpos($msg, 'invalid_grant') !== false || strpos($msg, 'Invalid user credentials') !== false) {
            $msg .= "\n\n⚠ HINT: The Username and Password fields are for your Contabo API credentials — NOT your regular Contabo login password. Please go to your Contabo Control Panel → API section and click 'Send Link' to generate a dedicated API Password.";
        }
        return ['success' => false, 'error' => $msg];
    }
}

function contabo_CreateAccount($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired. Please contact the administrator.";
    try {
        $api = contabo_getApiClient($params);
        
        // Extract product config
        $region = $params['configoption1'];
        $productId = $params['configoption2'];
        $imageId = $params['configoption3'];
        
        // Check if client selected configurable options for these
        if (isset($params['configoptions']['Region'])) $region = $params['configoptions']['Region'];
        if (isset($params['configoptions']['Product ID'])) $productId = $params['configoptions']['Product ID'];
        if (isset($params['configoptions']['Image ID'])) $imageId = $params['configoptions']['Image ID'];
        
        $hostname = $params['domain'];
        if (empty($hostname)) {
            $prefix = !empty($params['configoption4']) ? $params['configoption4'] : 'vps-';
            $hostname = $prefix . $params['serviceid'] . '.local';
        }
        
        // Call API to create instance
        $response = $api->createInstance($imageId, $region, $productId);
        
        if (isset($response['data'][0]['instances'][0]['instanceId'])) {
            $instanceId = $response['data'][0]['instances'][0]['instanceId'];
            
            // Save instance ID and update hostname
            Capsule::table('tblhosting')
                ->where('id', $params['serviceid'])
                ->update([
                    'dedicatedip' => '', // Will be updated later when available
                    'domain' => $hostname,
                    'notes' => "Instance ID: " . $instanceId . "\r\n" . $params['model']->notes
                ]);
                
            // Set custom field for Instance ID if exists
            $customField = Capsule::table('tblcustomfields')
                ->where('type', 'product')
                ->where('relid', $params['pid'])
                ->where('fieldname', 'like', '%Instance ID%')
                ->first();
                
            if ($customField) {
                $exists = Capsule::table('tblcustomfieldsvalues')->where('fieldid', $customField->id)->where('relid', $params['serviceid'])->count();
                if ($exists) {
                    Capsule::table('tblcustomfieldsvalues')->where('fieldid', $customField->id)->where('relid', $params['serviceid'])->update(['value' => $instanceId]);
                } else {
                    Capsule::table('tblcustomfieldsvalues')->insert(['fieldid' => $customField->id, 'relid' => $params['serviceid'], 'value' => $instanceId]);
                }
            }

            // We can optionally fire a custom hook or email here for notification
            run_hook('ContaboInstanceCreated', ['serviceid' => $params['serviceid'], 'instanceId' => $instanceId]);

            return 'success';
        }
        
        return 'Failed to extract Instance ID from response.';
        
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function contabo_SuspendAccount($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        if (!$instanceId) return 'Instance ID not found';
        
        $api->stopInstance($instanceId);
        return 'success';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function contabo_UnsuspendAccount($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        if (!$instanceId) return 'Instance ID not found';
        
        $api->startInstance($instanceId);
        return 'success';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function contabo_TerminateAccount($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        if (!$instanceId) return 'Instance ID not found';
        
        $api->cancelInstance($instanceId);
        return 'success';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

// --------------------------------------------------------------------------------
// Admin UI
// --------------------------------------------------------------------------------

function contabo_AdminServicesTabFields($params) {
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        
        if (!$instanceId) {
            return ['Contabo Status' => '<div class="errorbox">No Instance ID found. VPS might not be provisioned yet.</div>'];
        }

        $instanceData = $api->getInstance($instanceId);
        $instance = isset($instanceData['data'][0]) ? $instanceData['data'][0] : null;

        if (!$instance) {
            return ['Contabo Status' => '<div class="errorbox">Instance ID found but could not fetch data from API.</div>'];
        }

        $statusColor = (strtolower($instance['status']) === 'ok') ? '#198754' : '#dc3545';
        $statusText = strtoupper($instance['status'] === 'ok' ? 'Running' : $instance['status']);

        $html = '<div style="margin: 10px 0;">';
        $html .= '<span class="label" style="background-color: ' . $statusColor . ' !important; font-size: 14px; padding: 5px 10px; border-radius: 4px; color: #fff;">' . $statusText . '</span>';
        $html .= '<ul style="margin-top: 15px; padding-left: 20px;">';
        $html .= '<li><strong>Instance ID:</strong> ' . htmlspecialchars($instance['instanceId']) . '</li>';
        $html .= '<li><strong>Display Name:</strong> ' . htmlspecialchars($instance['displayName'] ?: $instance['name']) . '</li>';
        $html .= '<li><strong>Primary IPv4:</strong> ' . htmlspecialchars($instance['ipConfig']['v4']['ip']) . '</li>';
        $html .= '<li><strong>Region:</strong> ' . htmlspecialchars($instance['region']) . '</li>';
        $html .= '<li><strong>OS:</strong> ' . htmlspecialchars($instance['osType']) . '</li>';
        $html .= '</ul>';
        $html .= '</div>';

        return [
            'Contabo Information' => $html,
        ];
    } catch (\Exception $e) {
        return [
            'Contabo Error' => '<div class="errorbox">' . $e->getMessage() . '</div>',
        ];
    }
}

// --------------------------------------------------------------------------------
// Buttons
// --------------------------------------------------------------------------------

function contabo_AdminCustomButtonArray() {
    return [
        'Power On' => 'poweron',
        'Power Off' => 'poweroff',
        'Shut Down' => 'shutdown',
        'Reboot' => 'reboot',
    ];
}

function contabo_ClientAreaCustomButtonArray() {
    return [
        'Power On' => 'poweron',
        'Power Off' => 'poweroff',
        'Reboot' => 'reboot',
    ];
}

function contabo_ChangePassword($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    return 'success';
}

function contabo_poweron($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        if (!$instanceId) return 'Instance ID not found';
        
        $api->startInstance($instanceId);
        logActivity("Contabo VPS: Power On for Service ID {$params['serviceid']} (Instance: {$instanceId})", $params['userid']);
        return 'success';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function contabo_poweroff($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        if (!$instanceId) return 'Instance ID not found';
        
        $api->stopInstance($instanceId);
        logActivity("Contabo VPS: Power Off for Service ID {$params['serviceid']} (Instance: {$instanceId})", $params['userid']);
        return 'success';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function contabo_shutdown($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        if (!$instanceId) return 'Instance ID not found';
        
        $api->shutdownInstance($instanceId);
        logActivity("Contabo VPS: Shut Down for Service ID {$params['serviceid']} (Instance: {$instanceId})", $params['userid']);
        return 'success';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

function contabo_reboot($params) {
    if (!contabo_is_license_valid()) return "Contabo Module License is invalid or expired.";
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        if (!$instanceId) return 'Instance ID not found';
        
        $api->restartInstance($instanceId);
        logActivity("Contabo VPS: Reboot for Service ID {$params['serviceid']} (Instance: {$instanceId})", $params['userid']);
        return 'success';
    } catch (\Exception $e) {
        return $e->getMessage();
    }
}

// --------------------------------------------------------------------------------
// Helpers
// --------------------------------------------------------------------------------

// License Cache Helper (fallback if dashboard not loaded)
if (!function_exists('contabo_get_license_cache')) {
    function contabo_get_license_cache($setting) {
        try {
            if (class_exists('\WHMCS\Database\Capsule') && Capsule::schema()->hasTable('mod_contabo_license')) {
                return Capsule::table('mod_contabo_license')->where('setting', $setting)->value('value') ?: '';
            }
        } catch (\Exception $e) {}
        return '';
    }
}

function contabo_getInstanceId($params) {
    // 1. Try to get from custom fields
    if (isset($params['customfields']['Instance ID']) && !empty($params['customfields']['Instance ID'])) {
        return $params['customfields']['Instance ID'];
    }
    
    // 2. Try to get from notes
    if (preg_match('/Instance ID:\s*([0-9]+)/i', $params['model']->notes, $matches)) {
        return $matches[1];
    }
    
    return false;
}

// --------------------------------------------------------------------------------
// Client Area
// --------------------------------------------------------------------------------

function contabo_ClientArea($params) {
    if (!contabo_is_license_valid()) return;

    $action = isset($_REQUEST['contabo_action']) ? $_REQUEST['contabo_action'] : '';
    $error = '';
    $success = '';
    
    try {
        $api = contabo_getApiClient($params);
        $instanceId = contabo_getInstanceId($params);
        
        if (!$instanceId) {
            return [
                'templatefile' => 'templates/clientarea',
                'vars' => ['error' => 'Your VPS is currently provisioning or no Instance ID was found.']
            ];
        }
        
        // Handle post actions
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($action)) {
            try {
                if ($action === 'create_snapshot') {
                    $api->createSnapshot($instanceId, $_POST['name'], $_POST['description']);
                    $success = "Snapshot creation initiated.";
                } elseif ($action === 'delete_snapshot') {
                    $api->deleteSnapshot($instanceId, $_POST['snapshot_id']);
                    $success = "Snapshot deleted successfully.";
                } elseif ($action === 'restore_snapshot') {
                    $api->rollbackSnapshot($instanceId, $_POST['snapshot_id']);
                    $success = "Snapshot rollback initiated.";
                } elseif ($action === 'rebuild') {
                    $api->reinstallInstance($instanceId, $_POST['image_id']);
                    $success = "Server rebuild initiated.";
                    run_hook('ContaboInstanceRebuild', ['serviceid' => $params['serviceid'], 'instanceId' => $instanceId]);
                } elseif ($action === 'reset_password') {
                    $newPass = trim($_POST['new_password']);
                    if (strlen($newPass) < 8) {
                        throw new \Exception("Password must be at least 8 characters.");
                    }
                    $api->resetPassword($instanceId, $newPass);
                    $success = "Root password has been successfully reset.";
                    logActivity("Contabo VPS: Root password reset for Service ID {$params['serviceid']} (Instance: {$instanceId})", $params['userid']);
                }
            } catch (\Exception $e) {
                $error = "Action failed: " . $e->getMessage();
            }
        }
        
        // Fetch instance data
        $instanceData = $api->getInstance($instanceId);
        $instance = isset($instanceData['data'][0]) ? $instanceData['data'][0] : [];
        
        // Update WHMCS IP if empty
        if (!empty($instance['ipConfig']['v4']['ip']) && empty($params['model']->dedicatedip)) {
            Capsule::table('tblhosting')
                ->where('id', $params['serviceid'])
                ->update(['dedicatedip' => $instance['ipConfig']['v4']['ip']]);
        }
        
        // Handle AJAX tab loads
        $tab = isset($_REQUEST['tab']) ? $_REQUEST['tab'] : 'overview';
        
        $vars = [
            'serviceid' => $params['serviceid'],
            'instance' => $instance,
            'error' => $error,
            'success' => $success,
            'active_tab' => $tab,
        ];
        
        if ($tab === 'snapshots') {
            $snapshots = $api->getSnapshots($instanceId);
            $vars['snapshots'] = isset($snapshots['data']) ? $snapshots['data'] : [];
            return [
                'templatefile' => 'templates/snapshots',
                'vars' => $vars
            ];
        } elseif ($tab === 'rebuild') {
            $images = $api->getImages();
            $vars['images'] = isset($images['data']) ? $images['data'] : [];
            return [
                'templatefile' => 'templates/rebuild',
                'vars' => $vars
            ];
        } elseif ($tab === 'history') {
            // Fetch WHMCS activity log for this service
            $logs = \WHMCS\Database\Capsule::table('tblactivitylog')
                ->where('userid', $params['userid'])
                ->where(function($query) use ($params, $instanceId) {
                    $query->where('description', 'like', "%Service ID {$params['serviceid']}%")
                          ->orWhere('description', 'like', "%Instance: {$instanceId}%");
                })
                ->orderBy('id', 'desc')
                ->limit(50)
                ->get();
            $vars['activity_logs'] = $logs;
        }

        return [
            'templatefile' => 'templates/clientarea',
            'vars' => $vars
        ];
        
    } catch (\Exception $e) {
        return [
            'templatefile' => 'templates/clientarea',
            'vars' => ['error' => 'API Error: ' . $e->getMessage()]
        ];
    }
}
