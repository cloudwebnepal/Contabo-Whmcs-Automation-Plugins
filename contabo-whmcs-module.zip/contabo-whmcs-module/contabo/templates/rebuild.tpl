{include file="./clientarea.tpl"}

<div style="animation: fadeIn 0.4s ease-out;">
    <div class="card" style="border: 2px solid #fee2e2;">
        <div class="card-header" style="background: #fef2f2; border-bottom: 1px solid #fecaca; color: #b91c1c;">
            <i class="fas fa-compact-disc"></i> Rebuild Operating System
        </div>
        <div class="card-body">
            
            <div class="alert alert-danger d-flex align-items-center p-4 mb-4" style="border-radius: 12px; border-left: 5px solid #dc3545;">
                <i class="fas fa-exclamation-triangle fa-2x me-4"></i>
                <div>
                    <h5 class="alert-heading fw-bold mb-1">Warning: Data Loss Imminent</h5>
                    <p class="mb-0">Rebuilding your server will permanently erase <strong>all data</strong> on the disk and reinstall the operating system from scratch. This action cannot be undone. Please ensure you have backups before proceeding.</p>
                </div>
            </div>

            <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}&tab=overview" id="rebuildForm">
                <input type="hidden" name="contabo_action" value="rebuild">
                
                <h6 class="fw-bold text-uppercase text-muted mb-3"><i class="fas fa-list-ul me-2"></i> Select New Operating System</h6>
                
                <div class="row g-3 mb-4">
                    {if $images}
                        {foreach from=$images item=img}
                            <div class="col-md-4 col-sm-6">
                                <label class="w-100 h-100">
                                    <input type="radio" name="image_id" value="{$img.imageId}" class="d-none os-radio" required>
                                    <div class="stat-box h-100 text-center os-card" style="cursor: pointer;">
                                        <i class="fab fa-linux fa-2x mb-2 text-secondary os-icon"></i>
                                        <div class="fw-bold os-name">{$img.name|escape}</div>
                                    </div>
                                </label>
                            </div>
                        {/foreach}
                    {else}
                        <div class="col-12 text-muted">No operating system images found.</div>
                    {/if}
                </div>
                
                <div class="d-flex align-items-center gap-3 bg-light p-3 rounded" style="border: 1px dashed #cbd5e1;">
                    <button type="button" class="btn btn-danger fw-bold px-4 py-2 js-confirm" data-confirm="WARNING: ALL DATA WILL BE LOST. Are you absolutely sure you want to rebuild this server?" id="rebuildBtn" disabled>
                        <i class="fas fa-sync-alt me-2"></i> Rebuild Server Now
                    </button>
                    <span class="text-muted small" id="rebuildNote"><i class="fas fa-arrow-left me-1"></i> Select an OS to continue</span>
                </div>
            </form>

        </div>
    </div>
</div>

<style>
.os-card { transition: all 0.2s; border: 2px solid transparent; }
.os-card:hover { border-color: #cbd5e1; background: #fff; }
.os-radio:checked + .os-card { border-color: #0d6efd; background: #eff6ff; box-shadow: 0 4px 12px rgba(13,110,253,0.15); }
.os-radio:checked + .os-card .os-icon { color: #0d6efd !important; }
.os-radio:checked + .os-card .os-name { color: #0d6efd; }
</style>

<script>
document.querySelectorAll('.os-radio').forEach(function(radio) {
    radio.addEventListener('change', function() {
        var btn = document.getElementById('rebuildBtn');
        var note = document.getElementById('rebuildNote');
        btn.disabled = false;
        note.innerHTML = '<i class="fas fa-check text-success me-1"></i> Ready to rebuild.';
    });
});
</script>
