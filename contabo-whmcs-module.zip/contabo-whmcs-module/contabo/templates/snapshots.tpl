{include file="./clientarea.tpl"}

<div style="animation: fadeIn 0.4s ease-out;">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <div><i class="fas fa-camera"></i> Manage Snapshots</div>
            <button class="btn btn-primary btn-sm fw-bold px-3 py-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#createSnapshotModal" data-toggle="modal" data-target="#createSnapshotModal">
                <i class="fas fa-plus me-1"></i> Create Snapshot
            </button>
        </div>
        <div class="card-body p-0">
            
            {if $snapshots && count($snapshots) > 0}
            <div class="table-responsive">
                <table class="table table-hover mb-0 align-middle" style="font-size: 14px;">
                    <thead class="bg-light text-muted small text-uppercase" style="border-bottom: 2px solid #e2e8f0;">
                        <tr>
                            <th class="ps-4 border-0 py-3 fw-bold">Name</th>
                            <th class="border-0 py-3 fw-bold">Description</th>
                            <th class="border-0 py-3 fw-bold">Created At</th>
                            <th class="pe-4 border-0 py-3 text-end fw-bold">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="border-top-0">
                        {foreach from=$snapshots item=snap}
                        <tr>
                            <td class="ps-4 fw-bold text-dark">
                                <i class="fas fa-hdd text-muted me-2"></i> {$snap.name|escape}
                            </td>
                            <td class="text-muted">{$snap.description|default:'<em class="opacity-50">No description</em>'}</td>
                            <td><span class="badge bg-light text-secondary border"><i class="far fa-clock me-1"></i> {$snap.createdDate}</span></td>
                            <td class="pe-4 text-end">
                                <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}&tab=snapshots" style="display:inline-block;">
                                    <input type="hidden" name="contabo_action" value="restore_snapshot">
                                    <input type="hidden" name="snapshot_id" value="{$snap.snapshotId}">
                                    <button type="button" class="btn btn-sm btn-warning text-dark fw-bold js-confirm px-3" data-confirm="Restore this snapshot? This will permanently overwrite your current server state."><i class="fas fa-undo me-1"></i> Restore</button>
                                </form>
                                
                                <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}&tab=snapshots" style="display:inline-block;" class="ms-1">
                                    <input type="hidden" name="contabo_action" value="delete_snapshot">
                                    <input type="hidden" name="snapshot_id" value="{$snap.snapshotId}">
                                    <button type="button" class="btn btn-sm btn-outline-danger js-confirm px-2" data-confirm="Delete this snapshot permanently?"><i class="fas fa-trash"></i></button>
                                </form>
                            </td>
                        </tr>
                        {/foreach}
                    </tbody>
                </table>
            </div>
            {else}
            <div class="p-5 text-center">
                <div class="text-muted mb-3" style="font-size: 4rem; opacity: 0.1;"><i class="fas fa-camera-retro"></i></div>
                <h5 class="fw-bold text-slate-700">No snapshots found</h5>
                <p class="text-muted small mb-0">You haven't created any snapshots for this instance yet.</p>
            </div>
            {/if}

        </div>
    </div>
</div>

<style>
/* Fix input field colors to prevent white text on white background */
#createSnapshotModal .form-control {
    background-color: #ffffff !important;
    color: #1e293b !important;
    border: 1px solid #cbd5e1 !important;
}
#createSnapshotModal .form-control::placeholder {
    color: #94a3b8 !important;
}
#createSnapshotModal .form-control:focus {
    border-color: #0d6efd !important;
    box-shadow: 0 0 0 3px rgba(13,110,253,0.1) !important;
}
</style>

<!-- Create Snapshot Modal -->
<div class="modal fade" id="createSnapshotModal" tabindex="-1" role="dialog" style="backdrop-filter: blur(3px);">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}&tab=snapshots">
        <input type="hidden" name="contabo_action" value="create_snapshot">
        <div class="modal-content border-0 shadow-lg" style="border-radius: 16px; overflow: hidden;">
          <div class="modal-header text-white" style="background: linear-gradient(135deg, #0d6efd, #0043a8); border: none; padding: 20px 25px;">
            <h5 class="modal-title fw-bold"><i class="fas fa-plus-circle me-2"></i> Create Snapshot</h5>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" data-dismiss="modal" aria-label="Close"></button>
          </div>
          <div class="modal-body p-4 bg-light">
            <div class="mb-3">
                <label class="fw-bold text-muted small text-uppercase mb-2">Snapshot Name</label>
                <input type="text" name="name" class="form-control" required placeholder="e.g. Before Upgrade" style="border-radius: 8px; padding: 12px 15px; border: 1px solid #cbd5e1;">
            </div>
            <div>
                <label class="fw-bold text-muted small text-uppercase mb-2">Description (Optional)</label>
                <textarea name="description" class="form-control" rows="3" style="border-radius: 8px; border: 1px solid #cbd5e1;" placeholder="Add some notes about this snapshot..."></textarea>
            </div>
          </div>
          <div class="modal-footer bg-white border-top-0 p-3">
            <button type="button" class="btn btn-light fw-bold text-muted px-4" data-bs-dismiss="modal" data-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-primary fw-bold px-4 shadow-sm" onclick="this.innerHTML='<i class=\'fas fa-spinner fa-spin me-2\'></i> Saving...'; this.form.submit();"><i class="fas fa-save me-1"></i> Save Snapshot</button>
          </div>
        </div>
    </form>
  </div>
</div>
