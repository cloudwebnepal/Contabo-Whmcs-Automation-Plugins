{if $error}
    <div class="alert alert-danger" style="animation: fadeIn 0.5s; border-radius: 12px; border-left: 5px solid #dc3545;">
        <i class="fas fa-exclamation-circle"></i> {$error}
    </div>
{/if}

{if $success}
    <div class="alert alert-success" style="animation: fadeIn 0.5s; border-radius: 12px; border-left: 5px solid #198754;">
        <i class="fas fa-check-circle"></i> {$success}
    </div>
{/if}

{if $instance}
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
.contabo-ui { font-family: 'Inter', sans-serif; color: #344767; }
.contabo-ui * { box-sizing: border-box; }
.contabo-ui .card { border: none; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); background: #fff; margin-bottom: 25px; transition: transform 0.2s ease, box-shadow 0.2s ease; overflow: hidden; }
.contabo-ui .card-header { background: #fff; border-bottom: 1px solid #f0f2f5; padding: 20px 25px; font-weight: 700; font-size: 1.1rem; color: #1e293b; display: flex; align-items: center; }
.contabo-ui .card-header i { color: #0d6efd; margin-right: 8px; }
.contabo-ui .card-body { padding: 25px; }

/* Status Badge */
.c-badge { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 30px; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
.c-badge.running { background: #d1e7dd; color: #0f5132; animation: pulse-green 2s infinite; }
.c-badge.stopped { background: #fff3cd; color: #856404; }
.c-badge.provisioning { background: #cff4fc; color: #055160; animation: pulse-blue 2s infinite; }
@keyframes pulse-green { 0%,100% { box-shadow: 0 0 0 0 rgba(25,135,84,0.4); } 50% { box-shadow: 0 0 0 5px rgba(25,135,84,0); } }
@keyframes pulse-blue { 0%,100% { box-shadow: 0 0 0 0 rgba(13,110,253,0.4); } 50% { box-shadow: 0 0 0 5px rgba(13,110,253,0); } }

/* Stats Grid */
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; }
.stat-box { background: #f8fafc; border-radius: 12px; padding: 18px; border: 1px solid #e2e8f0; transition: all 0.2s; }
.stat-box:hover { background: #fff; border-color: #cbd5e1; box-shadow: 0 4px 12px rgba(0,0,0,0.03); transform: translateY(-2px); }
.stat-box .stat-label { font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; display: flex; align-items: center; gap: 6px; }
.stat-box .stat-value { font-size: 1.1rem; font-weight: 700; color: #0f172a; word-break: break-all; }
.stat-box.primary .stat-value { color: #0d6efd; }

/* IP Box with Copy */
.ip-box { display: flex; align-items: center; justify-content: space-between; background: #f0fdf4; border: 1px dashed #86efac; padding: 12px 18px; border-radius: 10px; margin-bottom: 10px; }
.ip-box .ip-val { font-weight: 700; color: #166534; font-size: 1.1rem; font-family: monospace; }
.copy-btn { background: #dcfce7; border: none; color: #166534; padding: 6px 12px; border-radius: 6px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.copy-btn:hover { background: #bbf7d0; }

/* Buttons */
.btn-power { transition: all 0.2s; font-weight: 600; padding: 10px 24px; border-radius: 8px; border: none; display: inline-flex; align-items: center; gap: 8px; color: #fff; box-shadow: 0 4px 10px rgba(0,0,0,0.1); cursor: pointer; }
.btn-power:hover { transform: translateY(-2px); box-shadow: 0 6px 15px rgba(0,0,0,0.15); }
.btn-power:active { transform: translateY(0); }
.btn-power.btn-start { background: linear-gradient(135deg, #10b981, #059669); }
.btn-power.btn-stop { background: linear-gradient(135deg, #f59e0b, #d97706); }
.btn-power.btn-reboot { background: linear-gradient(135deg, #ef4444, #dc2626); }
.btn-power.loading { opacity: 0.8; pointer-events: none; }
.btn-power .spinner { display: none; width: 14px; height: 14px; border: 2px solid rgba(255,255,255,0.4); border-top-color: #fff; border-radius: 50%; animation: spin 0.7s linear infinite; }
.btn-power.loading .icon { display: none; }
.btn-power.loading .spinner { display: block; }

/* Tabs */
.c-tabs { display: flex; gap: 10px; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 10px; overflow-x: auto; }
.c-tab { text-decoration: none; padding: 10px 20px; border-radius: 8px; font-weight: 600; color: #64748b; transition: all 0.2s; white-space: nowrap; }
.c-tab:hover { background: #f1f5f9; color: #0f172a; }
.c-tab.active { background: #0d6efd; color: #fff; box-shadow: 0 4px 12px rgba(13,110,253,0.2); }

/* Activity Log */
.activity-list { list-style: none; padding: 0; margin: 0; }
.activity-item { display: flex; gap: 15px; padding: 15px 0; border-bottom: 1px solid #f1f5f9; }
.activity-item:last-child { border-bottom: none; }
.activity-icon { width: 36px; height: 36px; border-radius: 50%; background: #e0f2fe; color: #0284c7; display: flex; align-items: center; justify-content: center; font-size: 14px; flex-shrink: 0; }
.activity-details { flex-grow: 1; }
.activity-desc { font-weight: 500; color: #1e293b; margin-bottom: 4px; font-size: 14px; }
.activity-time { font-size: 12px; color: #94a3b8; }

/* Form Control */
.c-input { border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px 15px; width: 100%; transition: all 0.2s; font-family: 'Inter', sans-serif; background-color: #ffffff !important; color: #1e293b !important; }
.c-input::placeholder { color: #94a3b8 !important; }
.c-input:focus { outline: none; border-color: #0d6efd; box-shadow: 0 0 0 3px rgba(13,110,253,0.1); }

@keyframes spin { to { transform: rotate(360deg); } }
@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
</style>

<div class="contabo-ui">
    
    <!-- Header Card -->
    <div class="card" style="background: linear-gradient(135deg, #0f172a, #1e293b); color: white;">
        <div class="card-body d-flex flex-wrap justify-content-between align-items-center gap-3">
            <div>
                <h3 class="mb-1 fw-bold text-white"><i class="fas fa-server me-2 text-primary"></i> {$instance.displayName|default:$instance.name}</h3>
                <div class="text-white-50 small"><i class="fas fa-microchip me-1"></i> {$instance.vCpu} vCPU &nbsp;|&nbsp; <i class="fas fa-memory me-1"></i> {$instance.ramMb} MB RAM &nbsp;|&nbsp; <i class="fas fa-hdd me-1"></i> {$instance.diskMb} MB</div>
            </div>
            <div>
                {if strtolower($instance.status) === 'ok'}
                    <span class="c-badge running"><i class="fas fa-circle" style="font-size: 8px;"></i> RUNNING</span>
                {elseif strtolower($instance.status) === 'provisioning'}
                    <span class="c-badge provisioning"><i class="fas fa-spinner fa-spin"></i> PROVISIONING</span>
                {else}
                    <span class="c-badge stopped"><i class="fas fa-stop"></i> {$instance.status|upper}</span>
                {/if}
            </div>
        </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="c-tabs">
        <a href="clientarea.php?action=productdetails&id={$serviceid}&tab=overview" class="c-tab {if $active_tab == 'overview'}active{/if}"><i class="fas fa-info-circle me-1"></i> Overview</a>
        <a href="clientarea.php?action=productdetails&id={$serviceid}&tab=security" class="c-tab {if $active_tab == 'security'}active{/if}"><i class="fas fa-shield-alt me-1"></i> Security</a>
        <a href="clientarea.php?action=productdetails&id={$serviceid}&tab=history" class="c-tab {if $active_tab == 'history'}active{/if}"><i class="fas fa-history me-1"></i> Activity Logs</a>
        <a href="clientarea.php?action=productdetails&id={$serviceid}&tab=snapshots" class="c-tab {if $active_tab == 'snapshots'}active{/if}"><i class="fas fa-camera me-1"></i> Snapshots</a>
        <a href="clientarea.php?action=productdetails&id={$serviceid}&tab=rebuild" class="c-tab {if $active_tab == 'rebuild'}active{/if}"><i class="fas fa-compact-disc me-1"></i> Rebuild OS</a>
    </div>

    {if $active_tab == 'overview'}
    <!-- OVERVIEW TAB -->
    <div style="animation: fadeIn 0.4s ease-out;">
        <div class="card">
            <div class="card-header"><i class="fas fa-bolt"></i> Power Controls</div>
            <div class="card-body">
                <div class="d-flex flex-wrap gap-3">
                    <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}">
                        <input type="hidden" name="modop" value="custom"><input type="hidden" name="a" value="poweron">
                        <button type="button" class="btn-power btn-start js-confirm" data-confirm="Are you sure you want to start this server?"><span class="icon"><i class="fas fa-play"></i></span><span class="spinner"></span> Power On</button>
                    </form>
                    <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}">
                        <input type="hidden" name="modop" value="custom"><input type="hidden" name="a" value="poweroff">
                        <button type="button" class="btn-power btn-stop js-confirm" data-confirm="Are you sure you want to stop this server?"><span class="icon"><i class="fas fa-stop"></i></span><span class="spinner"></span> Power Off</button>
                    </form>
                    <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}">
                        <input type="hidden" name="modop" value="custom"><input type="hidden" name="a" value="reboot">
                        <button type="button" class="btn-power btn-reboot js-confirm" data-confirm="Are you sure you want to hard reboot this server?"><span class="icon"><i class="fas fa-sync-alt"></i></span><span class="spinner"></span> Reboot</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-7">
                <div class="card h-100">
                    <div class="card-header"><i class="fas fa-server"></i> Server Details</div>
                    <div class="card-body">
                        <div class="stat-grid">
                            <div class="stat-box">
                                <div class="stat-label"><i class="fab fa-linux"></i> Operating System</div>
                                <div class="stat-value">{$instance.osType}</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-label"><i class="fas fa-globe"></i> Region</div>
                                <div class="stat-value">{$instance.region}</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-label"><i class="fas fa-fingerprint"></i> Instance ID</div>
                                <div class="stat-value">{$instance.instanceId}</div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-label"><i class="fas fa-network-wired"></i> MAC Address</div>
                                <div class="stat-value">{$instance.macAddress}</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-5">
                <div class="card h-100">
                    <div class="card-header"><i class="fas fa-wifi"></i> Network Information</div>
                    <div class="card-body">
                        <div class="mb-3">
                            <div class="text-muted small fw-bold text-uppercase mb-2">Primary IPv4 Address</div>
                            <div class="ip-box">
                                <span class="ip-val" id="ipv4">{$instance.ipConfig.v4.ip}</span>
                                <button class="copy-btn" onclick="copyText('ipv4')"><i class="fas fa-copy"></i> Copy</button>
                            </div>
                        </div>
                        {if $instance.ipConfig.v6.ip}
                        <div>
                            <div class="text-muted small fw-bold text-uppercase mb-2">IPv6 Prefix</div>
                            <div class="ip-box" style="background:#f8fafc; border-color:#cbd5e1;">
                                <span class="ip-val" style="color:#334155; font-size:14px;" id="ipv6">{$instance.ipConfig.v6.ip}</span>
                                <button class="copy-btn" style="background:#e2e8f0; color:#334155;" onclick="copyText('ipv6')"><i class="fas fa-copy"></i> Copy</button>
                            </div>
                        </div>
                        {/if}
                    </div>
                </div>
            </div>
        </div>
    </div>
    {/if}

    {if $active_tab == 'security'}
    <!-- SECURITY TAB -->
    <div style="animation: fadeIn 0.4s ease-out;">
        <div class="card">
            <div class="card-header"><i class="fas fa-key"></i> Root Password Management</div>
            <div class="card-body">
                <p class="text-muted mb-4">You can securely reset the root password for your server here. A strong password is required (at least 8 characters).</p>
                
                <form method="post" action="clientarea.php?action=productdetails&id={$serviceid}&tab=security" style="max-width: 400px;">
                    <input type="hidden" name="contabo_action" value="reset_password">
                    
                    <div class="mb-3 position-relative">
                        <label class="form-label fw-bold small text-uppercase text-muted">New Root Password</label>
                        <div class="input-group">
                            <input type="password" name="new_password" id="newRootPass" class="form-control c-input" placeholder="Enter new strong password" required minlength="8">
                            <button class="btn btn-outline-secondary" type="button" onclick="togglePassword()"><i class="fas fa-eye" id="toggleIcon"></i></button>
                        </div>
                    </div>
                    
                    <button type="button" class="btn btn-primary fw-bold px-4 py-2 js-confirm" data-confirm="Are you sure you want to reset the root password? The server may require a reboot to apply."><i class="fas fa-save me-2"></i> Reset Password</button>
                </form>
            </div>
        </div>
    </div>
    <script>
    function togglePassword() {
        var x = document.getElementById("newRootPass");
        var icon = document.getElementById("toggleIcon");
        if (x.type === "password") {
            x.type = "text";
            icon.classList.remove("fa-eye");
            icon.classList.add("fa-eye-slash");
        } else {
            x.type = "password";
            icon.classList.remove("fa-eye-slash");
            icon.classList.add("fa-eye");
        }
    }
    </script>
    {/if}

    {if $active_tab == 'history'}
    <!-- HISTORY TAB -->
    <div style="animation: fadeIn 0.4s ease-out;">
        <div class="card">
            <div class="card-header"><i class="fas fa-history"></i> Recent Activity</div>
            <div class="card-body p-0">
                {if $activity_logs}
                    <ul class="activity-list">
                    {foreach from=$activity_logs item=log}
                        <li class="activity-item px-4">
                            <div class="activity-icon">
                                {if $log->description|lower|strpos:"power on" !== false}<i class="fas fa-play text-success"></i>
                                {elseif $log->description|lower|strpos:"power off" !== false}<i class="fas fa-stop text-warning"></i>
                                {elseif $log->description|lower|strpos:"reboot" !== false}<i class="fas fa-sync-alt text-danger"></i>
                                {elseif $log->description|lower|strpos:"rebuild" !== false}<i class="fas fa-compact-disc text-primary"></i>
                                {elseif $log->description|lower|strpos:"password" !== false}<i class="fas fa-key text-info"></i>
                                {else}<i class="fas fa-info"></i>{/if}
                            </div>
                            <div class="activity-details">
                                <div class="activity-desc">{$log->description}</div>
                                <div class="activity-time"><i class="far fa-clock me-1"></i> {$log->date} (IP: {$log->ipaddr})</div>
                            </div>
                        </li>
                    {/foreach}
                    </ul>
                {else}
                    <div class="text-center p-5 text-muted">
                        <i class="fas fa-history fa-3x mb-3 opacity-25"></i>
                        <h5>No recent activity found.</h5>
                    </div>
                {/if}
            </div>
        </div>
    </div>
    {/if}

</div>

<!-- Universal Confirmation Modal -->
<div class="modal fade" id="contaboConfirmModal" tabindex="-1" style="backdrop-filter: blur(3px);">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content border-0 shadow-lg" style="border-radius: 16px;">
      <div class="modal-body text-center p-4">
        <div class="mb-3">
            <div style="width: 60px; height: 60px; background: #fff3cd; color: #ffc107; border-radius: 50%; display: inline-flex; align-items: center; justify-content: center;">
                <i class="fas fa-exclamation-triangle fa-2x"></i>
            </div>
        </div>
        <h5 class="fw-bold mb-2 text-dark">Confirm Action</h5>
        <p class="text-muted small mb-4" id="contaboConfirmText"></p>
        <div class="d-flex gap-2 justify-content-center">
            <button type="button" class="btn btn-light fw-bold px-3" data-bs-dismiss="modal" data-dismiss="modal" style="border-radius: 8px;">Cancel</button>
            <button type="button" class="btn btn-primary fw-bold px-4" id="contaboConfirmBtn" style="border-radius: 8px;">Yes, Proceed</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
var currentForm = null;
var currentBtn = null;

// Bind to confirmation buttons
document.querySelectorAll('.js-confirm').forEach(function(btn) {
    btn.addEventListener('click', function(e) {
        e.preventDefault();
        currentForm = this.closest('form');
        currentBtn = this;
        
        var msg = this.getAttribute('data-confirm');
        document.getElementById('contaboConfirmText').innerText = msg;
        
        // Show modal (fallback support for BS4 and BS5)
        if (typeof bootstrap !== 'undefined' && bootstrap.Modal) {
            var m = new bootstrap.Modal(document.getElementById('contaboConfirmModal'));
            m.show();
        } else if (typeof jQuery !== 'undefined') {
            jQuery('#contaboConfirmModal').modal('show');
        } else {
            if (confirm(msg)) executeAction();
        }
    });
});

// Execute action on modal confirm
document.getElementById('contaboConfirmBtn').addEventListener('click', function() {
    if (typeof jQuery !== 'undefined') {
        jQuery('#contaboConfirmModal').modal('hide');
    }
    executeAction();
});

function executeAction() {
    if (currentBtn && currentBtn.tagName.toLowerCase() === 'button') {
        currentBtn.classList.add('loading');
    }
    if (currentForm) {
        currentForm.submit();
    }
}

// Copy to Clipboard
function copyText(elementId) {
    var text = document.getElementById(elementId).innerText;
    navigator.clipboard.writeText(text).then(function() {
        alert("Copied to clipboard!");
    });
}
</script>
{/if}
